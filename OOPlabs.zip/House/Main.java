public class Main {

    public static void main(String[] args) {
        House house = new House(5.04);
        house.getSqu();
        house.reserveRoom();
        Stars stars = new Stars("ghefestg@gmail.com");
        stars.replacement();
        stars.printEmail();
    }
}
