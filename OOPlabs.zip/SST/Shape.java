public interface Shape {
	double calcSqr();
}
